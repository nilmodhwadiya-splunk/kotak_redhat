"""
Decoding tables for the various encodings implemented. This allows the encoding
definitions to be neater.
"""