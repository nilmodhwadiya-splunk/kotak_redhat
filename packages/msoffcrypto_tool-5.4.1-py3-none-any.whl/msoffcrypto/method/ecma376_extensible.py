class ECMA376Extensible:
    def __init__(self):
        pass
